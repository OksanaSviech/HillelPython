class NumberOfStudentsError(Exception):
    def __init__(self, error_message= "Cannot add more than 10 students to the group"):
        super().__init__(error_message)

